-- AlterEnum
ALTER TYPE "ProductType" ADD VALUE 'TICKET';
