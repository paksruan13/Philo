const teamService = require('../services/teamService');
const { emitLeaderboardUpdate } = require('../services/leaderboardService');
const { prisma } = require('../config/database');

const getAllTeams = async (req, res) => {
  try {
    const teams = await teamService.getAllTeams();
    res.json(teams);
  } catch (err) {
    console.error('Error fetching teams:', err);
    res.status(500).json({ error: err.message });
  }
};

const getTeamScore = async (req, res) => {
  const { id } = req.params;
  try {
    const score = await teamService.getTeamScore(id);
    if (!score) {
      return res.status(404).json({ error: 'Team not found' });
    }
    res.json(score);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const createTeam = async (req, res) => {
  const { name, coachId } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Name is required' });
  }

  try {
    const team = await teamService.createTeamWithCode({
      name,
      coachId: coachId || null,
    });
    await emitLeaderboardUpdate(req.app.get('io'));
    res.status(201).json(team);
  } catch (err) {
    console.error('Error creating team:', err);
    res.status(500).json({ error: err.message });
  }
};

const assignCoach = async (req, res) => {
  try {
    const {teamId} = req.params;
    const {coachId} = req.body;

    const result = await prisma.$transaction(async (tx) => {
      const currentTeam = await tx.team.findUnique({
        where: { id: teamId },
        select: { coachId: true }
      });

      if(currentTeam?.coachId) {
        await tx.user.update({
          where: { id: currentTeam.coachId },
          data: { teamId: null }
        });
      }

      const updatedTeam = await tx.team.update({
        where:{ id: teamId },
        data: { coachId: coachId || null },
        include: {
          coach: {select: { id: true, name: true, email: true } },
        }
      });

      if( coachId) {
        await tx.user.update({
          where: { id: coachId },
          data: { teamId: teamId }
        });
      }

      return updatedTeam;
    });

    res.json({
      message: 'Coach assigned successfully',
      team: result
    });
  } catch (err) {
    console.error('Error assigning coach:', err);
    res.status(500).json({ error: 'Failed to assign coach' });
  }
};

const getAdminTeams = async(req, res) => {
  try {
    const teams = await teamService.getTeamsWithDetails();
    res.json(teams);
  } catch (err) {
    console.error('Error fetching teams for admin:', err);
    res.status(500).json({ error: err.message });
  }
};

const updateAdminTeam = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, coachId, isActive, groupMeLink } = req.body;
    
    console.log('🔍 Updating team with data:', { id, name, coachId, isActive, groupMeLink });
    
    const result = await prisma.$transaction(async (tx) => {
      const currentTeam = await tx.team.findUnique({
        where: { id },
        select: { coachId: true }
      });
      
      if (currentTeam?.coachId) {
        await tx.user.update({
          where: { id: currentTeam.coachId },
          data: { teamId: null }
        });
      }

      // ADD THE MISSING PARTS
      const updatedTeam = await tx.team.update({
        where: { id },
        data: { 
          name, 
          coachId: coachId || null, 
          isActive: isActive !== undefined ? isActive : true,
          groupMeLink: groupMeLink || null
        },
        include: {
          coach: {
            select: { id: true, name: true, email: true }
          },
          members: {
            select: { id: true, name: true, email: true, role: true }
          }
        }
      });

      if (coachId) {
        await tx.user.update({
          where: { id: coachId },
          data: { teamId: id }
        });
      }

      return updatedTeam;
    }); 

    res.json({
      message: 'Team updated successfully',
      team: result
    });
  } catch (err) {
    console.error('Error updating team:', err);
    res.status(500).json({ error: 'Failed to update team' });
  }
};

const getMyTeamDashboard = async (req, res) => {
  try{
    const userId = req.user.id;
    const dashboardData = await teamService.getDashboardData(userId);
    res.json(dashboardData);
  } catch (err) {
    console.error('Error fetching team dashboard:', err);

    if(err.message === 'User is not assigned to any team') {
      return res.status(404).json({ error: 'You are not assigned to any team' });
    }

    if(err.message === 'Team not found') {
      return res.status(404).json({ error: 'Team not found' });
    }

    res.status(500).json({ error: 'Failed to fetch team dashboard' });
  }
};

const getMyTeamActivities = async ( req, res ) => {
  try {
    const userId = req.user.id;

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { teamId: true }
    });

    if(!user?.teamId) {
      return res.status(404).json({ error: 'You are not assigned to any team' });
    }

    const activities = await teamService.getActivitiesWithSubmissionStatus(user.teamId, userId);
    res.json(activities);
  } catch (err) {
    console.error('Error fetching team activities:', err);
    res.status(500).json({ error: 'Failed to fetch team activities' });
  }
}

const getTeamMembers = async (req, res) => {
  try {
    const { id } = req.params;
    const user = req.user;
    
    // Verify access for coaches
    if (user.role === 'COACH') {
      const team = await prisma.team.findUnique({
        where: { id },
        select: { coachId: true, name: true }
      });
      
      if (!team) {
        return res.status(404).json({ error: 'Team not found' });
      }
      
      if (team.coachId !== user.id) {
        return res.status(403).json({ error: 'Access denied to this team' });
      }
    }
    
    const members = await prisma.user.findMany({
      where: { 
        teamId: id,
        isActive: true 
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        createdAt: true
      },
      orderBy: { name: 'asc' }
    });

    res.json(members);
  } catch (error) {
    console.error('Error fetching team members:', error);
    res.status(500).json({ error: 'Failed to fetch team members' });
  }
};

module.exports = {
  getAllTeams,
  getTeamScore,
  createTeam,
  assignCoach,
  updateAdminTeam,
  getAdminTeams,
  getMyTeamDashboard,
  getMyTeamActivities,
  getTeamMembers
};